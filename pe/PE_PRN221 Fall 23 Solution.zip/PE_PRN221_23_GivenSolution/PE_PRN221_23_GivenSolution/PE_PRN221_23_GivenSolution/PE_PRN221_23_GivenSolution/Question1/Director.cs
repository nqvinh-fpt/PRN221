﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
	public class Director
	{
        public string Name { get; set; } = null!;
        public DateTime? Dob { get; set; }
        public string? Description { get; set; }
        public bool? Male { get; set; }
        public string? Nationality { get; set; }

    }
}
