using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Question2.Pages.Schedule
{
    public class ByDateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
