﻿namespace TCP_IP
{
    public class Class1
    {

    }
}