﻿using Debt_Management.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Debt_Management.DAO
{
	public class AdmRequireDAO
	{
		private DebtCompanyContext context = new DebtCompanyContext();
		private static AdmRequireDAO instance = null;
		private static readonly object instanceLock = new object();
		private AdmRequireDAO() { }

		public static AdmRequireDAO Instance
		{
			get
			{
				lock (instanceLock)
				{
					if (instance == null)
					{
						instance = new AdmRequireDAO();
					}
					return instance;
				}
			}
		}
		
		public IEnumerable<AdminRequire> GetAdminRequires()
		{
			List<AdminRequire> requires;
			try
			{
				requires = context.AdminRequires.ToList();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return requires;
		}

		public void AddRequire(AdminRequire require)
		{
			DebtCompanyContext myDB = new DebtCompanyContext();
			try
			{
				myDB.AdminRequires.Add(require);
				myDB.SaveChanges();

			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}
        public AdminRequire GetReqByID(int ID)
        {
			AdminRequire req = null;
            try
            {
                var myDB = new DebtCompanyContext();
                req = myDB.AdminRequires.SingleOrDefault(o => o.RequireId == ID);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return req;
        }
		public IEnumerable<AdminRequire> GetReqBySupplierID(int ID)
        {
			List<AdminRequire> req = null;
            try
            {
                var myDB = new DebtCompanyContext();
                req = myDB.AdminRequires.Where(r => r.SupplierId == ID).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return req;
        }

        public void UpdateRequire(AdminRequire require)
		{
			DebtCompanyContext myDB = new DebtCompanyContext();
			AdminRequire _req = GetReqByID(require.RequireId);
			if(_req != null)
			{
                myDB.Entry<AdminRequire>(require).State = EntityState.Modified;
                myDB.SaveChanges();
			}
			else
			{
				throw new Exception("error");
			}
        }


	}
}
