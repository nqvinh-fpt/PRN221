# A Hotel Management System

## Built with C#, WPF and Entity Framework